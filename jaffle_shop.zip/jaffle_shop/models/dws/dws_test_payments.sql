with tmp_test_payments as (

  select * from {{ ref('dwd_test_payments') }}

),
dws_test_payments as (

 select a.payment_method,
        count(1) nums
   from tmp_test_payments a
  group by a.payment_method
)

select a.*,
       to_char(now()::timestamp + '-1 day','yyyymmdd') date_id
 from dws_test_payments a