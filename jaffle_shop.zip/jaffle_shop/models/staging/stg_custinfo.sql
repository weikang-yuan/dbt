with tmp_custinfo as (

  select * from {{ source('cust_relation','cust_info') }}
)

select * from tmp_custinfo