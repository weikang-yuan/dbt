with tmp_test_payments as(

select *
  from {{ ref('stg_payments') }}
 where amount > 15

)
select * from tmp_test_payments
